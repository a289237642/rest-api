create type rlm$apmultvcl is table of rlm$apvarclst;
/

