create type        exf$text as object (
   preferences  VARCHAR2(1000)
);
/

