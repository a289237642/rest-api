create view USER_RLM4J_ATTRIBUTE_ALIASES as
SELECT esname, esattals, esattexp,
          decode(bitand(aliastype, 1), 1, 'PREDICATE', 'LHS')
  FROM  rlm4j$attraliases
  WHERE esowner =  SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

