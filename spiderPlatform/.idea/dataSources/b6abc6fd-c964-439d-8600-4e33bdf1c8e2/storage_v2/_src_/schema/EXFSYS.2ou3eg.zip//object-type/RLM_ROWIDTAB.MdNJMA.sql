create type        rlm$rowidtab is table of VARCHAR2(38);
/

