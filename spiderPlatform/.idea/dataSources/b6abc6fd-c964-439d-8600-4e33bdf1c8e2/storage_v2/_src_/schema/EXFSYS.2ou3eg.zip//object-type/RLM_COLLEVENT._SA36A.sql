create type        rlm$collevent is object
  (rlm$cetmstp timestamp, rlm$ceref VARCHAR(38), rlm$ceattvals EXFSYS.RLM$APVARCLST);
/

