create type rlm$apnumblst is VARRAY(32) of NUMBER;
/

