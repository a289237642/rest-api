create type exf$expfuncrefs is VARRAY(1000) of VARCHAR2(32);
/

