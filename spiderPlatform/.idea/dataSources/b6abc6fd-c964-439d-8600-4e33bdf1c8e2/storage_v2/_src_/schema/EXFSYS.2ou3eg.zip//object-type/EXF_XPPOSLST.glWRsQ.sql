create type exf$xpposlst is VARRAY(100) of NUMBER
/

