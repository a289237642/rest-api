create type        rlm$dateval is table of timestamp;
/

