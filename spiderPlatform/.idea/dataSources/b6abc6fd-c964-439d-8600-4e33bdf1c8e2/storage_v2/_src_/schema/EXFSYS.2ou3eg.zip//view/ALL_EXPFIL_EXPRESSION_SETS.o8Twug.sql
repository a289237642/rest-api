create view ALL_EXPFIL_EXPRESSION_SETS as
select exsowner, exstabnm, exscolnm, exsatsnm,
            exsetlanl, exsetnexp, avgprpexp, exsetsprp
  from exf$exprset, all_tables at
  where at.owner = exsowner and at.table_name = exstabnm
/

comment on table ALL_EXPFIL_EXPRESSION_SETS is 'List of expression sets accessible to the current user'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.OWNER is 'Owner of the expression set'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.EXPR_TABLE is 'The table storing the expression set in the owner''s schema'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.EXPR_COLUMN is 'The column storing the expression set'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.ATTRIBUTE_SET is 'Attribute set used for the expression set'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.LAST_ANALYZED is 'The date of the most recent time the expression set is analyzed'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.NUM_EXPRESSIONS is 'Number of expressions (disjunctions) in the expression set'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.PREDS_PER_EXPR is 'Average number of conjunctive predicates per expressions'
/

comment on column ALL_EXPFIL_EXPRESSION_SETS.NUM_SPARSE_PREDS is 'Number of sparse predicates in the expression set'
/

