create type rlm$apvarclst is VARRAY(32) of VARCHAR2(100);
/

