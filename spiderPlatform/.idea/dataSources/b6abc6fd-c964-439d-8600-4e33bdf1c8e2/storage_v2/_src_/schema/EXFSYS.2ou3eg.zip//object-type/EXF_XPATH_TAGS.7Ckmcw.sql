create type exf$xpath_tags as VARRAY(490) of exf$xpath_tag;
/

