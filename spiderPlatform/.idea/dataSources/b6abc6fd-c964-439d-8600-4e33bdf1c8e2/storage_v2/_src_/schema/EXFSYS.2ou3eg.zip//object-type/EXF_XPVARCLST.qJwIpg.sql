create type exf$xpvarclst is VARRAY(100) of VARCHAR2(500)
/

