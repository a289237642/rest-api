create package dbms_expfil AUTHID CURRENT_USER AS

  procedure copy_attribute_set (
              from_set   IN   VARCHAR2,    --- name of an existing att set
              to_set     IN   VARCHAR2);   --- new set name

  procedure create_attribute_set (
              attr_set   IN   VARCHAR2,    --- attr set name
              from_type  IN   VARCHAR2     --- ADT for attributes
                         default 'NO');

  procedure assign_attribute_set (
              attr_set   IN   VARCHAR2,    --- attr set name
              expr_tab   IN   VARCHAR2,    --- name of the table
              expr_col   IN   VARCHAR2,    --- exp column in the table
              force      IN   VARCHAR2     --- to use existing expressions
                         default 'FALSE');

  procedure add_elementary_attribute (
              attr_set   IN   VARCHAR2,    --- attr set name
              attr_name  IN   VARCHAR2,    --- attr name
              attr_type  IN   VARCHAR2,    --- attr type
              attr_defvl IN   VARCHAR2     --- default value for attr
                         default NULL);

  procedure add_elementary_attribute (
              attr_set   IN   VARCHAR2,    --- attr set name
              attr_name  IN   VARCHAR2,    --- table alias (name)
              tab_alias  IN   exf$table_alias);  -- table alias for

  procedure add_elementary_attribute (
              attr_set   IN   VARCHAR2,    --- attr set name
              attr_name  IN   VARCHAR2,    --- attr name
              attr_type  IN   VARCHAR2,    --- attr type
              text_pref  IN   exf$text);   --- text data type pref

  procedure add_functions (
              attr_set   IN   VARCHAR2,    --- attr set name
              funcs_name IN   VARCHAR2);   --- function/package/type name

  procedure unassign_attribute_set (
              expr_tab   IN   VARCHAR2,    --- table with expr. column
              expr_col   IN   VARCHAR2);   --- column storing expr. set

  procedure drop_attribute_set (
              attr_set   IN   VARCHAR2);   --- attr set name

  procedure modify_operator_list (
              attr_set   IN   VARCHAR2,    --- attr set name
              attr_name  IN   VARCHAR2,    --- attribute to be modified
              attr_oper  IN   EXF$INDEXOPER);  --- list of new operators

  procedure default_index_parameters (
              attr_set   IN   VARCHAR2,    --- attribute set name
              attr_list  IN   EXF$ATTRIBUTE_LIST,
                                           --- stored and indexed attrs
              operation  IN   VARCHAR2     --- to ADD or DROP
                               default 'ADD');

  procedure index_parameters(
              expr_tab   IN   VARCHAR2,    --- expression set table
              expr_col   IN   VARCHAR2,    --- expression set column
              attr_list  IN   EXF$ATTRIBUTE_LIST default null,
              operation  IN   VARCHAR2     --- DEFAULT/ADD/DROP/CLEAR
                               default 'ADD');

  procedure default_xpindex_parameters (
              attr_set   IN   VARCHAR2,    --- attribute set
              xmlt_attr  IN   VARCHAR2,    --- XMLType attribute name
              xptag_list IN   EXF$XPATH_TAGS, --- common elements/attributes
                                              --- in xpath expressions
              operation  IN   VARCHAR2     --- to ADD/DROP
                                default 'ADD');

  procedure xpindex_parameters(
              expr_tab   IN   VARCHAR2,    --- expression set table
              expr_col   IN   VARCHAR2,    --- expression set column
              xmlt_attr  IN   VARCHAR2,    --- XMLType attribute name
              xptag_list IN   EXF$XPATH_TAGS, --- common elements/attributes
                                              --- in xpath expressions
              operation  IN   VARCHAR2     --- to ADD/DROP
                                default 'ADD');

  procedure get_exprset_stats (
              expr_tab   IN   VARCHAR2,    --- table storing expression set
              expr_col   IN   VARCHAR2);   --- column in the table with set

  procedure clear_exprset_stats (
              expr_tab   IN   VARCHAR2,    --- table storing expression set
              expr_col   IN   VARCHAR2);   --- column in the table with set

  procedure grant_privilege (
              expr_tab   IN  VARCHAR2,     --- table w/ the expr column
              expr_col   IN  VARCHAR2,     --- column storing the expressions
              priv_type  IN  VARCHAR2,     --- type of priv to be granted
              to_user    IN  VARCHAR2);    --- user to which the priv is
                                           ---   granted
  procedure revoke_privilege (
              expr_tab   IN  VARCHAR2,     --- table with the expr column
              expr_col   IN  VARCHAR2,     --- column storing the expressions
              priv_type  IN  VARCHAR2,     --- type of privilege to be granted
              from_user  IN  VARCHAR2);    --- user from which the priv is
                                           ---   revoked

  procedure build_exceptions_table (
              exception_tab IN VARCHAR2);  -- exception table to be created --

  procedure validate_expressions (
              expr_tab      IN  VARCHAR2,  --- expressions table
              expr_col      IN  VARCHAR2,  --- column storing expressions
              exception_tab IN  VARCHAR2   --- exception table
                    default null);

  procedure defrag_index (
              idx_name   IN  VARCHAR2);    --- expfil index to defrag

  procedure sync_text_indexes (
              expr_tab      IN  VARCHAR2);  --- sync text indexes
end;
/

