create type exf$xpdatelst is VARRAY(100) of DATE
/

