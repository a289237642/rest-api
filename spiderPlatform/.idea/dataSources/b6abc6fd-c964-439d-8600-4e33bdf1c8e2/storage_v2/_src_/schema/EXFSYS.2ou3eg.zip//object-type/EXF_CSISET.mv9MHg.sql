create type exf$csiset as varray (1000) of exf$csicode;
/

