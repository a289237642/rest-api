create type exf$attribute_list as VARRAY(490) of exf$attribute;
/

