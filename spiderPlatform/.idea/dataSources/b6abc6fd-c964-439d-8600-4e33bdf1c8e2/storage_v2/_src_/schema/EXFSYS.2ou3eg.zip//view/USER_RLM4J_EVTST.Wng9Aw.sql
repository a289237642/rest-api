create view USER_RLM4J_EVTST as
SELECT evt.dbowner, evt.dbesname, evt.javapck, evt.javacls,
         decode(evt.estflags, 1, 'YES','NO')
  FROM rlm4j$evtstructs evt
  where evt.dbowner = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

