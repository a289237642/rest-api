create type        rlm$keyval is table of VARCHAR2(1000);
/

