create type exf$xpnumblst is VARRAY(100) of NUMBER
/

