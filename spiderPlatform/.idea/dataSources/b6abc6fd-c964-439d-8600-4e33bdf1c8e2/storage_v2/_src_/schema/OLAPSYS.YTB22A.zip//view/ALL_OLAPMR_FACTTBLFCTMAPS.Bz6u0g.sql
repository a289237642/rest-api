create view ALL$OLAPMR_FACTTBLFCTMAPS as
select a.owner owner,
       a.cube_name cube_name,
       a.measure_name measure_name,
       a.fact_table_owner fact_table_owner,
       a.fact_table_name fact_table_name,
       a.column_name column_name,
       c.data_type data_type,
       c.data_length data_length,
       c.data_precision data_precision,
       (case when c.data_type = 'NUMBER' then 0
              when c.data_type = 'DOUBLE' then 5
              when c.data_type = 'FLOAT' then 4
              when c.data_type = 'DATE' then 7
              when c.data_type = 'LONG' then 3
              else 1 end) olap_api_data_type
from olapsys.all$olap2ucube_measure_maps a,
     all_olap_columns c
where a.dim_hier_combo_id = 0
 and a.fact_table_owner = c.owner
 and a.fact_table_name = c.table_name
 and a.column_name = c.column_name
with read only
/

