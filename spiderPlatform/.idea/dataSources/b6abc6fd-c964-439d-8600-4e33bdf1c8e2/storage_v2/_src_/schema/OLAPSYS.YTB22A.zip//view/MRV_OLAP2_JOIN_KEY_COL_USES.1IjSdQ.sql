create view MRV$OLAP2_JOIN_KEY_COL_USES as
select
  jkcu.owner owner,
  jkcu.dimension_name dimension_name,
  jkcu.hierarchy_name hierarchy_name,
  jkcu.child_level_name child_level_name,
  jkcu.table_owner table_owner,
  jkcu.table_name table_name,
  jkcu.column_name column_name,
  jkcu.position position,
  jkcu.join_key_type join_key_type
 from olapsys.cwm2$mrall_join_key_col_uses jkcu,
      olapsys.olap_session_objects oso
 where oso.version_id = jkcu.version_id and
       oso.id = jkcu.id
/

