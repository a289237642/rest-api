create view ALL$OLAP_DIM_ATTR_USES as
SELECT
/*+ ORDERED */
  u.username owner
, d.name dimension_name
, dat.physicalname dim_attribute_name
, lvl.physicalname level_name
, lat.name lvl_attribute_name
FROM
  dba_users u
, sys.obj$ d
, cwm$dimensionattribute dat
, cwm$itemuse use1
, cwm$itemuse use2
, cwm$levelattribute lat
, cwm$level lvl
, sys.dimlevel$ l
, sys.dimattr$ a
, sys.col$ c
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = dat.itemcontainer_irid
AND dat.irid = use1.mappable_irid
AND use1.operation_irid = use2.operation_irid_1
AND use2.mappable_irid = lat.irid
AND lat.itemcontainer_irid = lvl.irid
AND lvl.dimension_irid = l.dimobj#
AND l.dimobj# = a.dimobj#
AND l.levelid# = a.levelid#
AND a.detailobj# = c.obj#
AND a.col# = c.col#
AND lvl.physicalname = l.levelname
AND lat.type_irid = c.obj#
AND lat.physicalname = c.name
WITH READ ONLY
/

