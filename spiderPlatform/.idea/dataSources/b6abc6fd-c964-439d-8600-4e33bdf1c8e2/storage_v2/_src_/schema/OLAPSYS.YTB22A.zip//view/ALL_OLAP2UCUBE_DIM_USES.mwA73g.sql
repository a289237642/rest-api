create view ALL$OLAP2UCUBE_DIM_USES as
  SELECT cdu.irid cube_dimension_use_id
, sch.physicalname owner
, cub.physicalname cube_name
, cdu.dimension_owner
, cdu.dimension_name
, cdu.name dimension_alias
, cdu.calc_hierarchy_name default_calc_hierarchy_name
, cdu.cubedimensionuse_irid dependent_on_dim_use_id
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$cubedimensionuse cdu
, cwm$dimension cd
, dba_users du
, sys.obj$ do
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND cub.irid = cdu.cube_irid
AND cdu.dimension_owner = du.username
AND cdu.dimension_name = do.name
AND du.user_id = do.owner#
AND do.obj# = cd.irid
AND do.type# = 43
AND cd.irid = cdu.abstractdimension_irid
AND (cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
union all
select cube_dimension_use_id, owner, cube_name, dimension_owner,
       dimension_name, dimension_alias, default_calc_hierarchy_name,
       dependent_on_dim_use_id
from olapsys.all$olap2_cube_dim_uses
with read only
/

