create view ALL$AW_LOAD_CUBE_AGG_LEVELS as
  select c.owner owner,
          c.name cube_name,
          cl.name load_name,
          cagg.name aggregation_name,
          d.owner dimension_owner,
          d.name dimension_name,
          l.name level_name
   from cwm2$awcubeload cl,
        cwm2$awcubeagg cagg,
        cwm2$awcubeagglevel caggl,
        cwm2$awcubeloadaggplan clap,
        cwm2$cube c,
        cwm2$dimension d,
        cwm2$level l
   where cl.cube_irid = c.irid and
         cl.version_id = 'CWM2' and
         (c.invalid = 'N' or c.invalid = 'O') and
         caggl.cubeagg_irid = cagg.irid and
         caggl.dim_irid = d.irid and
         caggl.level_irid = l.irid and
         clap.cubeagg_irid = cagg.irid and
         clap.cubeload_irid = cl.irid  and
         (cwm2$security.fact_table_visible(c.irid) = 'Y'
            OR EXISTS (select null from v$enabledprivs
                       where priv_number in (-47)))
  union all
   select sch.physicalname owner,
          c.physicalname cube_name,
          cl.name load_name,
          cagg.name aggregation_name,
          u.username dimension_owner,
          dim1.name dimension_name,
          l.name level_name
   from cwm$model sch,
        cwm$cube c,
        cwm$dimension dim1,
        dba_users u,
        sys.obj$ o,
        sys.dim$ d,
        cwm2$awcubeload cl,
        cwm2$awcubeagg cagg,
        cwm2$awcubeagglevel caggl,
        cwm2$awcubeloadaggplan clap,
        cwm$level l
   where sch.irid = c.datamodel_irid and
         cl.cube_irid = c.irid and
         cl.version_id = 'CWM' and
         caggl.cubeagg_irid = cagg.irid and
         caggl.dim_irid = dim1.irid and
         caggl.level_irid = l.irid and
         clap.cubeagg_irid = cagg.irid and
         clap.cubeload_irid = cl.irid and
         d.obj# = dim1.irid and
         o.obj# = d.obj# and
         u.user_id = o.owner# and
         (cwm$util.fact_table_visible(c.irid) = 'Y'
            OR EXISTS (select null from v$enabledprivs
                       where priv_number in (-47)))
with read only
/

