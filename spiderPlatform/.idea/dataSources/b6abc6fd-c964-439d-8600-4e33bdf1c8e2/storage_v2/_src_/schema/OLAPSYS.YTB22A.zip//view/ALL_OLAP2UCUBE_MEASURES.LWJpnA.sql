create view ALL$OLAP2UCUBE_MEASURES as
  SELECT distinct sch.physicalname owner
, cub.physicalname cube_name
, msr.physicalname measure_name
, msr.displayname display_name
, msr.description short_description
, msr.description description
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$measure msr
, cwm$cubedimensionuse cdu
, cwm$dimension cd
, dba_users du
, sys.obj$ do
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND cub.irid = msr.itemcontainer_irid
AND cdu.cube_irid = cub.irid
AND cdu.dimension_owner = du.username
AND cdu.dimension_name = do.name
AND du.user_id = do.owner#
AND do.type# = 43
AND do.obj# = cd.irid
AND cd.irid = cdu.abstractdimension_irid
AND (    cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
union all
select owner, cube_name, measure_name, display_name, short_description, description
from olapsys.all$olap2_cube_measures
with read only
/

