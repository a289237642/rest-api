create view ALL$OLAP2_CUBES as
select
  c.owner owner,
  c.name cube_name,
  c.invalid invalid,
  c.displayname display_name,
  c.shortdescription short_description,
  c.description description,
  nvl(c.MVSummaryCode, 'GS') mv_summarycode,
  decode(c.invalid, 'N', 'DEFAULT', 'O', 'OLAPI', 'INVALID') type_of_validation
from olapsys.CwM2$Cube c
  where (c.invalid = 'N' or c.invalid = 'O') and
  (cwm2$security.fact_table_visible(c.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
with read only
/

