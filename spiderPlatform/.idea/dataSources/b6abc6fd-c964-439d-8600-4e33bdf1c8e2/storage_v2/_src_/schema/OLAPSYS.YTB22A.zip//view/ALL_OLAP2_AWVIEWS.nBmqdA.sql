create view ALL$OLAP2_AWVIEWS as
select
awv.view_owner view_owner,
awv.view_name view_name,
col.name rowtocellcol_name,
awv.aw_owner aw_owner,
awv.aw_name aw_name
from olapsys.cwm2$awviews awv,
     sys.col$ col
where awv.table_id = col.obj# (+) and
      awv.rowtocellcol_id = col.col# (+)
with read only
/

