create view ALL$AW_LOAD_CUBE_FILT as
select
   lcm.owner owner,
   lcm.cube_name cube_name,
   lcm.load_name load_name,
   lf.Fact_Table_Owner table_owner,
   lf.Fact_Table_Name  table_name,
   lf.filtercondition filter_condition
 from olapsys.all$aw_load_cube_map lcm,
      olapsys.cwm2$awcubeloadfilter lf
 where lcm.load_irid = lf.cubeload_irid
with read only
/

