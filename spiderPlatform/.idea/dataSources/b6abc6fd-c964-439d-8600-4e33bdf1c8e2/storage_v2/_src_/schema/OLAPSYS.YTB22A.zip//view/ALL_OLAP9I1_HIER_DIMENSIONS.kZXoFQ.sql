create view ALL$OLAP9I1_HIER_DIMENSIONS as
SELECT distinct
  u.username              owner,
  o.name                  dimension_name,
  dim.pluralname          plural_name,
  dim.displayname         display_name,
  dim.description         short_description,
  dim.description         description,
  display_hierarchy_name  default_display_hierarchy,
  (case when ce.classification_irid = 28 then 'Time'
       else 'Other'
       end)    descriptor_value
FROM
  sys.dim$                d,
  dba_users               u,
  sys.obj$                o,
  olapsys.cwm$dimension           dim,
  sys.hier$               h,
  olapsys.cwm$classificationentry ce
WHERE o.type# = 43 AND
      u.user_id = o.owner# AND
      o.obj#  = d.obj# AND
      d.obj#  = dim.irid AND
      (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
          OR EXISTS
          /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
          (SELECT null FROM v$enabledprivs
           WHERE priv_number IN (-47,-215,-216,-217))) AND
      o.obj# = h.dimobj#
AND dim.irid = ce.element_irid (+) and
    ce.name (+) = 'DIMENSION'
WITH READ ONLY
/

