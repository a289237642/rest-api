create view MRV$MRALL_ENTITY_PARAMETERS as
select
 ep.DESCRIPTOR_ID,
 ep.DESCRIPTOR_NAME,
 ep.ENTITY_OWNER,
 ep.ENTITY_NAME,
 ep.CHILD_ENTITY_NAME,
 ep.SECONDARY_CHILD_ENTITY_NAME,
 ep.PARAMETER_NAME,
 ep.PARAMETER_VALUE
from olapsys.cwm2$mrall_entity_parameters ep,
     olapsys.olap_session_objects oso
 where oso.version_id = ep.version_id and
       oso.id = ep.id
/

