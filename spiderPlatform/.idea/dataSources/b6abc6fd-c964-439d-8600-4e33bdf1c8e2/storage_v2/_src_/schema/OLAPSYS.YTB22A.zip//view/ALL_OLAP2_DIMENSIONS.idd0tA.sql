create view ALL$OLAP2_DIMENSIONS as
select
  d.owner owner,
  d.name dimension_name,
  d.pluralname plural_name,
  d.displayname display_name,
  d.shortdescription short_description,
  d.description description,
  (case when h.hidden = 'N' then h.name
        else null end) default_display_hierarchy,
  d.invalid invalid,
  d.dimensiontype dimension_type
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h
where invalid = 'N' and
       d.DefaultHier_IRID = h.irid (+) and
       (cwm2$security.dimension_tables_visible(d.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
with read only
/

