create view ALL$OLAP_DESCRIPTOR_TYPES as
SELECT
  cty.name descriptor_type
, ot.name entity_type
FROM
  cwm$classificationtype cty
, cwm$objecttype ot
WHERE cty.name <> 'ORACLE_OLAP_CATALOG'
AND cty.irid = ot.classificationtype_irid
WITH READ ONLY
/

