create view ALL$AW_LOAD_CUBE_MEAS as
  select
  lcm.owner owner,
  lcm.cube_name cube_name,
  lcm.load_name load_name,
  m.name measure_name,
  clm.name measure_target_name,
  clm.displayname measure_target_display_name,
  clm.description measure_target_description
 from
   olapsys.all$aw_load_cube_map lcm,
   olapsys.cwm2$measure m,
   olapsys.cwm2$awcubeloadmeasure clm
 where
   lcm.cube_irid = m.cube_irid and
   lcm.load_irid = clm.cubeload_irid and
   m.irid = clm.measure_irid and
   lcm.version_id = 'CWM2'
union all
 select
  lcm.owner owner,
  lcm.cube_name cube_name,
  lcm.load_name load_name,
  m.name measure_name,
  clm.name measure_target_name,
  clm.displayname measure_display_name,
  clm.description measure_target_description
 from
   olapsys.all$aw_load_cube_map lcm,
   olapsys.cwm$measure m,
   olapsys.cwm2$awcubeloadmeasure clm
 where
   lcm.cube_irid = m.itemcontainer_irid and
   lcm.load_irid = clm.cubeload_irid and
   m.irid = clm.measure_irid and
   lcm.version_id = 'CWM'
with read only
/

