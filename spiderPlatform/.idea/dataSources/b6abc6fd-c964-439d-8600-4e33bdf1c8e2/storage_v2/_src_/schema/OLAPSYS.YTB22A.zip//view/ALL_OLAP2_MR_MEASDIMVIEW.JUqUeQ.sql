create view ALL$OLAP2_MR_MEASDIMVIEW as
select
 owner || '.' || cube_name || '.' || measure_name measid,
 display_name display_name,
 description description
from olapsys.all$olap2ucube_measures
with read only
/

