create view ALL$OLAP_FUNCTIONS as
SELECT
  f.name function_name
, f.description description
FROM
  cwm$function f
WITH READ ONLY
/

