create view MRV$OLAP1_FACTTBLKEYMAPS as
select
  ftkm.owner owner,
  ftkm.cube_name cube_name,
  ftkm.dimension_owner dimension_owner,
  ftkm.dimension_name dimension_name,
  ftkm.level_name level_name,
  ftkm.fact_table_owner fact_table_owner,
  ftkm.fact_table_name fact_table_name,
  ftkm.column_name column_name,
  ftkm.column_position column_position,
  ftkm.mv_summary_code mv_summary_code,
  ftkm.data_type data_type,
  ftkm.data_length data_length,
  ftkm.data_precision data_precision
 from olapsys.cwm2$mrfacttblkeymaps ftkm,
      olapsys.olap_session_objects oso
 where oso.version_id = ftkm.version_id and
       oso.id = ftkm.id
/

