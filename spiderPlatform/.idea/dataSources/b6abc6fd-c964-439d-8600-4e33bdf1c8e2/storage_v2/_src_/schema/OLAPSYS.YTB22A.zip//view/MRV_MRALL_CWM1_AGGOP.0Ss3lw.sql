create view MRV$MRALL_CWM1_AGGOP as
select
 c1aop.owner,
 c1aop.cube_name,
 c1aop.measure_name,
 c1aop.dimension_owner,
 c1aop.dimension_name,
 c1aop.func_name,
 c1aop.table_owner,
 c1aop.table_name,
 c1aop.column_name
 from olapsys.cwm2$mrall_cwm1_aggop c1aop,
      olapsys.olap_session_objects oso
 where oso.version_id = c1aop.version_id and
       oso.id = c1aop.id
/

