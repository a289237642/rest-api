create view ALL$OLAP2_ENTITY_DESC_USES as
  select
 ce.classification_irid descriptor_id,
 cub.owner entity_owner,
 cub.name entity_name,
 null child_entity_name,
 null secondary_child_entity_name
from /* CUBE2 */
  cwm$classification c,
  cwm$classificationentry ce,
  cwm$classificationtype cty,
  cwm2$cube cub
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'CUBE2' and
      ce.element_irid = cub.irid and
      (cub.invalid = 'N' or cub.invalid = 'O') and
      (cwm2$security.fact_table_visible(cub.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
UNION ALL select
 ce.classification_irid descriptor_id,
 cub.owner entity_owner,
 cub.name entity_name,
 meas.name child_entity_name,
 null secondary_child_entity_name
from /* MEASURE2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$cube cub,
 cwm2$measure meas
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'MEASURE2' and
      ce.element_irid = meas.irid and
      meas.cube_irid = cub.irid and
      (cub.invalid = 'N' or cub.invalid = 'O') and
      (cwm2$security.fact_table_visible(cub.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 dat.name child_entity_name,
 null secondary_child_entity_name
from /* DIMENSION ATTRIBUTE2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$dimensionattribute dat
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'DIMENSION ATTRIBUTE2' and
      ce.element_irid = dat.irid and
      dat.dimension_irid = dim.irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 lvl.name child_entity_name,
 lat.name secondary_child_entity_name
from /* LEVEL ATTRIBUTE2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$dimensionattribute dat,
 cwm2$levelattribute lat,
 cwm2$level lvl
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name = 'LEVEL ATTRIBUTE2' and
      ce.element_irid = lat.irid and
      lat.dimattr_irid = dat.irid and
      dat.dimension_irid = dim.irid and
      lvl.irid = lat.level_irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 ce.secondary_object_name child_entity_name,
 null secondary_child_entity_name
from /* DIMENSION2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name  = 'DIMENSION2' and
      ce.element_irid = dim.irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 hier.name child_entity_name,
 null secondary_child_entity_name
from /* HIERARCHY2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$hierarchy hier
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name  = 'HIERARCHY2' and
      dim.irid = hier.dimension_irid and
      ce.element_irid = hier.irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 lvl.name child_entity_name,
 null secondary_child_entity_name
from /* LEVEL2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$level lvl
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name  = 'LEVEL2' and
      dim.irid = lvl.dimension_irid and
      ce.element_irid = lvl.irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
with read only
/

