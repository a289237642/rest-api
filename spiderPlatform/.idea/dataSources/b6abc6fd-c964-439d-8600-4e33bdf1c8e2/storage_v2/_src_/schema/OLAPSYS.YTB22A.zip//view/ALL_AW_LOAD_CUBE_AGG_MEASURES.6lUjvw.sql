create view ALL$AW_LOAD_CUBE_AGG_MEASURES as
  select c.owner cube_owner,
          c.name cube_name,
          cl.name load_name,
          cagg.name aggregation_name,
          m.name measure_name
   from
     cwm2$cube c,
     cwm2$measure m,
     cwm2$awcubeload cl,
     cwm2$awcubeagg cagg,
     cwm2$awcubeaggmeasure cagm,
     cwm2$awcubeloadaggplan clap
   where
     cl.cube_irid = c.irid and
     cl.version_id = 'CWM2' and
     (c.invalid = 'N' or c.invalid = 'O') and
     cagm.cubeagg_irid = cagg.irid and
     clap.cubeagg_irid = cagg.irid and
     clap.cubeload_irid = cl.irid and
     cagm.measure_irid = m.irid and
     m.cube_irid = c.irid and
     (cwm2$security.fact_table_visible(c.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
  union all
   select sch.physicalname cube_owner,
          c.physicalname cube_name,
          cl.name load_name,
          cagg.name aggregation_name,
          m.physicalname measure_name
   from
      cwm$cube c,
      cwm$measure m,
      cwm$model sch,
      cwm2$awcubeload cl,
      cwm2$awcubeagg cagg,
      cwm2$awcubeaggmeasure cagm,
      cwm2$awcubeloadaggplan clap
   where
      cl.cube_irid = c.irid and
      cl.version_id = 'CWM' and
      cagm.cubeagg_irid = cagg.irid and
      clap.cubeagg_irid = cagg.irid and
      clap.cubeload_irid = cl.irid and
      cagm.measure_irid = m.irid and
      m.itemcontainer_irid = c.irid and
      sch.irid = c.datamodel_irid and
      (cwm$util.fact_table_visible(c.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
with read only
/

