create view MRV$OLAP2_CATALOGS as
select
 CATALOG_ID,
 CATALOG_NAME,
 PARENT_CATALOG_ID,
 DESCRIPTION
 from olapsys.cwm2$mrall_catalogs mrcat
/

