create view ALL$OLAP_CUBE_MEASURE_MAPS as
SELECT
  sch.physicalname owner
, cub.physicalname cube_name
, msr.physicalname measure_name
, use2.object_owner fact_table_owner
, use2.object_name fact_table_name
, use2.secondary_object_name column_name
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$measure msr
, cwm$itemuse use1
, cwm$itemuse use2
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND (    cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
AND cub.irid = msr.itemcontainer_irid
AND msr.irid = use1.mappable_irid
AND use1.operation_irid = use2.operation_irid_1
WITH READ ONLY
/

