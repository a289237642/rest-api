create view ALL$OLAP2_DIM_HIERARCHIES as
select
  d.owner owner,
  d.name dimension_name,
  h.name hierarchy_name,
  h.displayname display_name,
  h.shortdescription short_description,
  h.description description,
  h.solvedcode solved_code
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h
where d.irid = h.dimension_irid and
      d.invalid = 'N' and
      h.hidden = 'N' and
       (cwm2$security.dimension_tables_visible(d.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
with read only
/

