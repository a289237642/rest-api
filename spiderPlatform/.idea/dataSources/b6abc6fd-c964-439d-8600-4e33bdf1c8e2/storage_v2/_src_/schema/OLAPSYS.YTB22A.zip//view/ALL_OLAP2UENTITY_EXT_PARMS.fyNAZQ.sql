create view ALL$OLAP2UENTITY_EXT_PARMS as
  SELECT
  ce.classification_irid descriptor_id
, c.name descriptor_name
, sch.physicalname entity_owner
, cub.physicalname entity_name
, ce.secondary_object_name child_entity_name
, ce.tertiary_object_name secondary_child_entity_name
, cvp.parametername parameter_name
, cvp.parametervalue parameter_value
, null parameter_value2
, null parameter_value3
, null parameter_value4
, null position
FROM /* DENSE INDICATOR */
  cwm$classification c
, cwm$classificationentry ce
, cwm2$classificationvaluepair cvp
, cwm$classificationtype cty
, cwm$cube cub
, cwm$cubedimensionuse cdu
, cwm$model sch
, dba_users u
, cwm$dimension cd
, dba_users du
, sys.obj$ do
WHERE cty.irid = c.classificationtype_irid
AND cty.name <> 'ORACLE_OLAP_CATALOG'
AND c.irid = ce.classification_irid
AND ce.name = 'DENSE INDICATOR'
AND ce.element_irid = cdu.irid
AND cub.irid = cdu.cube_irid
AND cdu.dimension_name = ce.tertiary_object_name
AND ce.irid = cvp.classentry_irid (+)
AND cub.datamodel_irid = sch.irid
AND sch.physicalname = u.username
AND cdu.dimension_owner = du.username
AND cdu.dimension_name = do.name
AND du.user_id = do.owner#
AND do.obj# = cd.irid
AND do.type# = 43
AND cd.irid = cdu.abstractdimension_irid
AND (cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
UNION ALL select
 ce.classification_irid descriptor_id,
 c.name descriptor_name,
 cub.owner entity_owner,
 cub.name entity_name,
 ce.secondary_object_name child_entity_name,
 ce.tertiary_object_name secondary_child_entity_name,
 cvp.parametername parameter_name,
 cvp.parametervalue parameter_value,
 null parameter_value2,
 null parameter_value3,
 null parameter_value4,
 null position
from /* DENSE INDICATOR2 */
  cwm$classification c,
  cwm$classificationentry ce,
  cwm2$classificationvaluepair cvp,
  cwm$classificationtype cty,
  cwm2$cube cub,
  cwm2$dimension dim,
  cwm2$cubedimensionuse cdu
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'DENSE INDICATOR2' and
      ce.element_irid = cdu.irid and
      cub.irid = cdu.cube_irid and
      ce.tertiary_object_name = dim.name and
      dim.irid = cdu.dimension_irid and
      ce.irid = cvp.classentry_irid (+) and
      (cub.invalid = 'N' or cub.invalid = 'O') and
      (cwm2$security.fact_table_visible(cub.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
UNION ALL SELECT
  ce.classification_irid descriptor_id
, c.name descriptor_name
, u.username entity_owner
, d.name entity_name
, ce.secondary_object_name child_entity_name
, null secondary_child_entity_name
, cvp.parametername parameter_name
, cvp.parametervalue parameter_value
, cvp.parametervalue2 parameter_value2
, null parameter_value3
, null parameter_value4
, cvp.position position
FROM /* DEFAULT MEMBER */
  cwm$classification c
, cwm$classificationentry ce
, cwm$classificationtype cty
, cwm2$classificationvaluepair cvp
, cwm$hierarchy hier
, sys.obj$ d
, dba_users u
WHERE cty.irid = c.classificationtype_irid
AND cty.name <> 'ORACLE_OLAP_CATALOG'
AND c.irid = ce.classification_irid
AND ce.irid = cvp.classentry_irid (+)
AND ce.name = 'DEFAULT MEMBER'
AND ce.element_irid = hier.irid
AND hier.dimension_irid = d.obj#
AND d.type# = 43 /* DIMENSION */
AND d.owner# = u.user_id
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
UNION ALL SELECT
  ce.classification_irid descriptor_id
, c.name descriptor_name
, u.username entity_owner
, d.name entity_name
, ce.secondary_object_name child_entity_name
, null secondary_child_entity_name
, cvp.parametername parameter_name
, cvp.parametervalue parameter_value
, cvp.parametervalue2 parameter_value2
, null parameter_value3
, null parameter_value4
, cvp.position position
FROM /* DEFAULT MEMBER */
  cwm$classification c
, cwm$classificationentry ce
, cwm$classificationtype cty
, cwm2$classificationvaluepair cvp
, sys.obj$ d
, dba_users u
WHERE cty.irid = c.classificationtype_irid
AND cty.name <> 'ORACLE_OLAP_CATALOG'
AND c.irid = ce.classification_irid
AND ce.irid = cvp.classentry_irid (+)
AND ce.name = 'DEFAULT MEMBER'
AND ce.element_irid = d.obj#
AND d.type# = 43 /* DIMENSION */
AND d.owner# = u.user_id
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
UNION ALL SELECT
 ce.classification_irid descriptor_id,
 c.name descriptor_name,
 dim.owner entity_owner,
 dim.name entity_name,
 ce.secondary_object_name child_entity_name,
 null secondary_child_entity_name,
 cvp.parametername parameter_name,
 cvp.parametervalue parameter_value,
 cvp.parametervalue2 parameter_value2,
 null parameter_value3,
 null parameter_value4,
 cvp.position position
from /* DEFAULT MEMBER2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm2$classificationvaluepair cvp,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$hierarchy hier
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.irid = cvp.classentry_irid (+) and
      ce.name  = 'DEFAULT MEMBER2' and
      ce.element_irid = hier.irid and
      hier.dimension_irid = dim.irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
UNION ALL SELECT
  ce.classification_irid descriptor_id
, c.name descriptor_name
, u.username entity_owner
, d.name entity_name
, ce.secondary_object_name child_entity_name
, ce.tertiary_object_name secondary_child_entity_name
, cvp.parametername parameter_name
, cvp.parametervalue parameter_value
, null parameter_value2
, null parameter_value3
, null parameter_value4
, null position
FROM /* ESTIMATED CARDINALITY */
  cwm$classification c
, cwm$classificationentry ce
, cwm$classificationtype cty
, cwm2$classificationvaluepair cvp
, cwm$level lev
, sys.obj$ d
, dba_users u
WHERE cty.irid = c.classificationtype_irid
AND cty.name <> 'ORACLE_OLAP_CATALOG'
AND c.irid = ce.classification_irid
AND ce.irid = cvp.classentry_irid (+)
AND ce.name = 'ESTIMATED CARDINALITY'
AND ce.element_irid = lev.irid
AND lev.dimension_irid = d.obj#
AND d.type# = 43 /* DIMENSION */
AND d.owner# = u.user_id
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
UNION ALL SELECT
 ce.classification_irid descriptor_id,
 c.name descriptor_name,
 dim.owner entity_owner,
 dim.name entity_name,
 ce.secondary_object_name child_entity_name,
 ce.tertiary_object_name secondary_child_entity_name,
 cvp.parametername parameter_name,
 cvp.parametervalue parameter_value,
 null parameter_value2,
 null parameter_value3,
 null parameter_value4,
 null position
from /* ESTIMATED CARDINALITY2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm2$classificationvaluepair cvp,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$hierlevelrel hlr
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.irid = cvp.classentry_irid (+) and
      ce.name  = 'ESTIMATED CARDINALITY2' and
      ce.element_irid = hlr.irid and
      hlr.dimension_irid = dim.irid and
      dim.invalid = 'N' and
      (cwm2$security.dimension_tables_visible(dim.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
UNION ALL select
 ce.classification_irid descriptor_id,
 c.name descriptor_name,
 cub.owner entity_owner,
 cub.name entity_name,
 ce.secondary_object_name child_entity_name,
 ce.tertiary_object_name secondary_child_entity_name,
 cvp.parametername parameter_name,
 cvp.parametervalue parameter_value,
 cvp.parametervalue2 parameter_value2,
 cvp.parametervalue3 parameter_value3,
 cvp.parametervalue4 parameter_value4,
 cvp.position position
from /* FACT TABLE JOIN2 */
  cwm$classification c,
  cwm$classificationentry ce,
  cwm2$classificationvaluepair cvp,
  cwm$classificationtype cty,
  cwm2$cube cub,
  cwm2$dimension dim,
  cwm2$cubedimensionuse cdu
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'FACT TABLE JOIN2' and
      ce.element_irid = cdu.irid and
      cub.irid = cdu.cube_irid and
      ce.tertiary_object_name = dim.name and
      dim.irid = cdu.dimension_irid and
      ce.irid = cvp.classentry_irid (+) and
      (cub.invalid = 'N' or cub.invalid = 'O') and
      (cwm2$security.fact_table_visible(cub.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
with read only
/

