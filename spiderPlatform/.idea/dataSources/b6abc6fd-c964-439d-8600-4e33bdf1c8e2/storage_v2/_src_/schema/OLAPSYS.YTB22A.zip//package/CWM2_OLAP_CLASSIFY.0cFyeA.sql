create package cwm2_olap_classify as

  procedure add_entity_descriptor_use(p_DescName varchar2,
                                      p_EntityType varchar2,
                                      p_EntityOwner varchar2,
                                      p_EntityName varchar2,
                                      p_EntityChildName varchar2 default null,
                                      p_EntitySecondaryChildName varchar2 default null,
                                      p_ParameterName varchar2 default null,
                                      p_ParameterValue varchar2 default '<null>');


  procedure add_entity_denseindicator_use(p_Owner varchar2,
                                          p_CubeName varchar2,
                                          p_DimensionOwner varchar2,
                                          p_DimensionName varchar2,
                                          p_DenseIndicator varchar2);


  procedure add_entity_cardinality_use(p_Owner varchar2,
                                       p_DimensionName varchar2,
                                       p_HierarchyName varchar2,
                                       p_LevelName varchar2,
                                       p_EstCardinality number);


  procedure add_entity_defaultmember_use(p_Owner varchar2,
                                         p_DimensionName varchar2,
                                         p_HierarchyName varchar2,
                                         p_DefaultMember varchar2,
                                         p_DefaultMemberLevel varchar2,
                                         p_Position number default null);


  procedure add_entity_factjoin_use(p_Owner varchar2,
                                    p_CubeName varchar2,
                                    p_DimensionOwner varchar2,
                                    p_DimensionName varchar2,
                                    p_HierarchyName varchar2,
                                    p_DimensionTblOwner varchar2,
                                    p_DimensionTblName varchar2,
                                    p_DimensionColName varchar2,
                                    p_Position number default null);


  procedure remove_entity_descriptor_use(p_DescName varchar2,
                                         p_EntityType varchar2,
                                         p_EntityOwner varchar2,
                                         p_EntityName varchar2,
                                         p_EntityChildName varchar2 default null,
                                         p_EntitySecondaryChildName varchar2 default null);



end cwm2_olap_classify;
/

