create view ALL$OLAP_CUBE_DIM_USES as
SELECT
  cdu.irid cube_dimension_use_id
, sch.physicalname owner
, cub.physicalname cube_name
, cdu.dimension_owner
, cdu.dimension_name
, cdu.name dimension_alias
, cdu.cubedimensionuse_irid dependent_on_dim_use_id
, cdu.calc_hierarchy_name default_calc_hierarchy_name
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$cubedimensionuse cdu
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND (    cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
AND cub.irid = cdu.cube_irid
WITH READ ONLY
/

