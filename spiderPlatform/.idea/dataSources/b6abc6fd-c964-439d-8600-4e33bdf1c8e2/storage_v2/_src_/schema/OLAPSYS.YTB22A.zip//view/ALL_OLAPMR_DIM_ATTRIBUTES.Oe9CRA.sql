create view ALL$OLAPMR_DIM_ATTRIBUTES as
SELECT
  u.username                  owner,
  o.name                  dimension_name,
  att.physicalname        attribute_name,
  att.displayname         display_name,
  att.description         short_description,
  att.description         description,
  ce.classification_irid  desc_id
FROM
  dba_users               u,
  sys.obj$                o,
  cwm$dimensionattribute  att,
  cwm$classificationentry ce
WHERE o.type# = 43 AND
      u.user_id = o.owner# AND
      att.itemcontainer_irid = o.obj# AND
      att.irid = ce.element_irid(+) AND
      ce.name (+) = 'DIMENSION ATTRIBUTE' AND
      (   cwm$util.dimension_tables_visible(o.obj#) = 'Y'
          OR EXISTS
          /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
          (SELECT null FROM v$enabledprivs
           WHERE priv_number IN (-47,-215,-216,-217)))
WITH READ ONLY
/

