create view MRV$OLAP2_DIM_HIER_LEVEL_USES as
select
  dhlu.owner owner,
  dhlu.dimension_name dimension_name,
  dhlu.hierarchy_name hierarchy_name,
  dhlu.parent_level_name parent_level_name,
  dhlu.child_level_name child_level_name,
  dhlu.position position
 from olapsys.cwm2$mrall_dim_hier_level_uses dhlu,
      olapsys.olap_session_objects oso
 where oso.version_id = dhlu.version_id and
       oso.id = dhlu.id
/

