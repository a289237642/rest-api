create view ALL$OLAP_LEVEL_KEY_COLUMN_USES as
SELECT /*+ORDERED*/
  u.username owner
, d.name dimension_name
, l.levelname level_name
, c.name column_name
, k.keypos# position
FROM
  dba_users u
, sys.obj$ d
, sys.dimlevel$ l
, sys.dimlevelkey$ k
, sys.col$ c
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = l.dimobj#
AND l.dimobj# = k.dimobj#
AND l.levelid# = k.levelid#
AND k.detailobj# = c.obj#
AND k.col# = c.col#
WITH READ ONLY
/

