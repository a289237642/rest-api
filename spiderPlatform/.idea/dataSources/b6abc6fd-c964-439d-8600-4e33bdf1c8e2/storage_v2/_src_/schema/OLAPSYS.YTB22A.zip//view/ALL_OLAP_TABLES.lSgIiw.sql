create view ALL$OLAP_TABLES as
SELECT
  u.username owner
, t.name table_name
, decode (t.type#, 2, 'TABLE', 'VIEW') table_type
FROM
  dba_users u
, sys.obj$ t
WHERE u.user_id = t.owner#
AND t.type# IN (2,4)
AND (   t.owner# = UID
     OR t.obj# IN
       (SELECT obj# FROM sys.objauth$
        WHERE (   grantee# = UID
               OR grantee# IN
                 (SELECT privilege#
                  FROM sys.sysauth$
                  WHERE privilege# > 0
                  START WITH grantee# = UID
                  CONNECT BY PRIOR privilege# = grantee#)))
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
WITH READ ONLY
/

