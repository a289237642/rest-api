create view OS_PRC_DATA_V as
  SELECT A.ID ,
       A.YS_URL ,
       A.CL_URL ,
       A.ZWWB CONTENT,
       '' AS KEYWORDS,
       A.CGSJ TIME,
       A.BT SUBJECT,
       A.XWLY SOURCE,
       A.ZZLY TRANS,
       '新闻' TYPE
  FROM OPEN_USER.OS_DATA_NEWS A
UNION ALL
SELECT B.ID,
       B.YS_URL,
       B.CL_URL,
       B.BKJS,
       '' ,
       B.GXSJ,
       B.MC ,
       B.BKLY ,
       '采集',
       '百科'
  FROM OPEN_USER.OS_DATA_BAIKE B
UNION ALL
SELECT  ID,
      C.URL,
      '',
      C.CONTENT,
      C.KEYWORD,
      TO_DATE( C.FETCH_TIME,'YYYY-MM-DD HH24:MI:SS'),
      C.TITLE,
      C.SOURCE,
      '采集',
      'NEWS_SITE'
 FROM OPEN_USER.NEWS_SITE_DATA C
/

