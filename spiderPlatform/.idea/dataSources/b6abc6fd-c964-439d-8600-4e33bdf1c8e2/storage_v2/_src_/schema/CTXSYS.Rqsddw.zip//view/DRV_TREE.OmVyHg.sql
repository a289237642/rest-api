create view DRV$TREE as
select "IDXID","SECID","NODE_SEQ" from ctxsys.dr$tree
where idxid = SYS_CONTEXT('DR$APPCTX', 'IDXID')
with check option
/

