create package drv0ddl authid current_user is

   function generate_substrings(c sys_refcursor)
   return dr$substring_set
   pipelined;

   function generate_substrings2(c sys_refcursor)
   return dr$substring_set2
   pipelined;

end drv0ddl;
/

