create view CTX_CLASSES as
select  cla_name
          ,cla_desc  cla_description
     from  dr$class
    where  cla_system = 'N'
/

