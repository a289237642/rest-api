create type ctx_centroids as table of ctx_centroid;
/

