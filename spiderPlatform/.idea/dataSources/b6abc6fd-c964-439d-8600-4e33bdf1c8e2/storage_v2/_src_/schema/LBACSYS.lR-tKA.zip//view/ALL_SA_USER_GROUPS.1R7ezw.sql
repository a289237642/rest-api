create view ALL_SA_USER_GROUPS as
SELECT p.pol_name AS policy_name, ug.usr_name AS user_name,
          g.code AS grp, DECODE(ug.rw_access,'1','WRITE','READ') AS rw_access,
          ug.def_group, ug.row_group
     FROM LBACSYS.sa$pol p, LBACSYS.sa$user_groups ug, LBACSYS.sa$groups g
    WHERE p.pol#=ug.pol#
      AND ug.pol#=g.pol#
      AND ug.group# = g.group#
      AND (p.pol# in (select pol# from LBACSYS.sa$admin where usr_name=user)
           or
           ug.usr_name = sa_session.sa_user_name(lbac_cache.policy_name(p.pol#)))
/

