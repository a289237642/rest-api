create view ALL_SA_COMPARTMENTS as
SELECT p.pol_name as policy_name, c.comp# AS comp_num,
          c.code AS short_name, c.name AS long_name
     FROM LBACSYS.sa$pol p, LBACSYS.sa$compartments c
    WHERE p.pol# = c.pol#
      and (p.pol# in (select pol# from LBACSYS.sa$admin where usr_name=user)
           OR
          (c.pol#,c.comp#) in (select pol#,comp#
                               from LBACSYS.sa$user_compartments
                               where usr_name = sa_session.sa_user_name(
                                                 lbac_cache.policy_name(pol#))))
/

