create PACKAGE         sa_session AS

FUNCTION privileges (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION privs (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION min_level (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION max_level (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION max_read_label (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION max_write_label (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION comp_read (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION comp_write (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION group_read (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION group_write (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION label (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION read_label (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION write_label (policy_name IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION row_label (policy_name IN VARCHAR2)
RETURN VARCHAR2;

PROCEDURE set_label       (policy_name   IN VARCHAR2,
                           label         IN VARCHAR2);

PROCEDURE set_row_label   (policy_name   IN VARCHAR2,
                           label         IN VARCHAR2);

PROCEDURE save_default_labels    (policy_name   IN VARCHAR2);

PROCEDURE restore_default_labels (policy_name   IN VARCHAR2);

PROCEDURE set_access_profile(policy_name IN VARCHAR2,
                             user_name   IN VARCHAR2);

FUNCTION sa_user_name (policy_name IN VARCHAR2)
RETURN VARCHAR2;

END sa_session;
/

