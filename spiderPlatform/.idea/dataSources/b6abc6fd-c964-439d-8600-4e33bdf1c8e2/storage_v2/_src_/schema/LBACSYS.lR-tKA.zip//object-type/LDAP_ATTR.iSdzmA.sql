create TYPE         LDAP_ATTR AS OBJECT (
     attr_name        VARCHAR2(256),
     attr_value       VARCHAR2(4000),
     attr_bvalue      BLOB,
     attr_value_len   INTEGER,
     attr_type        INTEGER,  -- (0 - String, 1 - Binary)
     attr_mod_op      INTEGER
);
/

