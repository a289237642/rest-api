create PACKAGE         lbac_utl AS

FUNCTION system_info_exp(prepost IN  PLS_INTEGER,
                         connectstring  OUT VARCHAR2,
                         version        IN  VARCHAR2,
                         new_block      OUT PLS_INTEGER)
RETURN VARCHAR2;

FUNCTION instance_info_exp(name IN VARCHAR2,
                           schema IN VARCHAR2,
                           prepost IN PLS_INTEGER,
                           isdba IN PLS_INTEGER,
                           version IN VARCHAR2,
                           new_block OUT PLS_INTEGER)
   RETURN VARCHAR2;

FUNCTION schema_info_exp(schema IN VARCHAR2,
                         prepost IN PLS_INTEGER,
                         isdba IN PLS_INTEGER,
                         version IN VARCHAR2,
                         new_block OUT PLS_INTEGER)
   RETURN VARCHAR2;

/* String returned can be only 128 bytes long */
FUNCTION nls_substrb (in_string IN VARCHAR2,
                      num_bytes IN PLS_INTEGER )
RETURN VARCHAR2;
PRAGMA RESTRICT_REFERENCES (nls_substrb, RNDS, WNDS, RNPS, WNPS);

FUNCTION nls_validname (in_string IN VARCHAR2)
RETURN PLS_INTEGER;

FUNCTION number_policy_column
RETURN BOOLEAN;

FUNCTION label_flags(label IN LBAC_LABEL)
RETURN PLS_INTEGER;

FUNCTION label_flags(label_tag IN INTEGER)
RETURN PLS_INTEGER;

FUNCTION data_label(label IN LBAC_LABEL)
RETURN BOOLEAN;

FUNCTION user_data_label(label IN LBAC_LABEL)
RETURN BOOLEAN;

FUNCTION data_label(label_tag IN INTEGER)
RETURN BOOLEAN;

FUNCTION user_data_label(label_tag IN INTEGER)
RETURN BOOLEAN;

FUNCTION label_tagseq(label IN LBAC_LABEL)
RETURN LBAC_LABEL;

FUNCTION label_tagseq(label_tag IN NUMBER)
RETURN LBAC_LABEL;

FUNCTION label_exists(policy_name      IN VARCHAR2,
                      label_string     IN VARCHAR2,
                      label_tag        IN INTEGER,
                      bin_label        OUT LBAC_BIN_LABEL,
                      int_label        OUT VARCHAR2,
                      policy_strlabel  OUT VARCHAR2,
                      label_flags      OUT PLS_INTEGER)
RETURN PLS_INTEGER;

FUNCTION get_label_info(policy_name  IN  VARCHAR2,
                        label_string IN  VARCHAR2,
                        label_tag    IN OUT INTEGER,
                        label_flags  IN OUT INTEGER,
                        bin_label    OUT LBAC_BIN_LABEL,
                        int_label    OUT VARCHAR2,
                        policy_strlabel OUT VARCHAR2)
RETURN BOOLEAN;

END lbac_utl;
/

