create PACKAGE         to_label_list AS

-- This package builds lbac_label lists from character strings and
-- LBAC_LABELs

FUNCTION from_char (policy_name IN VARCHAR2,
                    format IN VARCHAR2,
                    label1 IN VARCHAR2)
RETURN lbac_label_list;

FUNCTION from_char (policy_name IN VARCHAR2,
                    format IN VARCHAR2,
                    label1 IN VARCHAR2,
                    label2 IN VARCHAR2)
RETURN lbac_label_list;

FUNCTION from_char (policy_name IN VARCHAR2,
                    format IN VARCHAR2,
                    label1 IN VARCHAR2,
                    label2 IN VARCHAR2,
                    label3 IN VARCHAR2)
RETURN lbac_label_list;

FUNCTION from_char (policy_name IN VARCHAR2,
                    format IN VARCHAR2,
                    label1 IN VARCHAR2,
                    label2 IN VARCHAR2,
                    label3 IN VARCHAR2,
                    label4 IN VARCHAR2)
RETURN lbac_label_list;

FUNCTION from_char (policy_name IN VARCHAR2,
                    format IN VARCHAR2,
                    label1 IN VARCHAR2,
                    label2 IN VARCHAR2,
                    label3 IN VARCHAR2,
                    label4 IN VARCHAR2,
                    label5 IN VARCHAR2)
RETURN lbac_label_list;

FUNCTION from_char (policy_name IN VARCHAR2,
                    format IN VARCHAR2,
                    label1 IN VARCHAR2,
                    label2 IN VARCHAR2,
                    label3 IN VARCHAR2,
                    label4 IN VARCHAR2,
                    label5 IN VARCHAR2,
                    label6 IN VARCHAR2)
RETURN lbac_label_list;

FUNCTION from_label (policy_name IN VARCHAR2,
                    label1 IN lbac_label)
RETURN lbac_label_list;

FUNCTION from_label ( policy_name IN VARCHAR2,
                    label1 IN lbac_label,
                    label2 IN lbac_label)
RETURN lbac_label_list;

FUNCTION from_label ( policy_name IN VARCHAR2,
                    label1 IN lbac_label,
                    label2 IN lbac_label,
                    label3 IN lbac_label)
RETURN lbac_label_list;

FUNCTION from_label (policy_name IN VARCHAR2,
                    label1 IN lbac_label,
                    label2 IN lbac_label,
                    label3 IN lbac_label,
                    label4 IN lbac_label)
RETURN lbac_label_list;

FUNCTION from_label (policy_name IN VARCHAR2,
                    label1 IN lbac_label,
                    label2 IN lbac_label,
                    label3 IN lbac_label,
                    label4 IN lbac_label,
                    label5 IN lbac_label)
RETURN lbac_label_list;

FUNCTION from_label (policy_name IN VARCHAR2,
                    label1 IN lbac_label,
                    label2 IN lbac_label,
                    label3 IN lbac_label,
                    label4 IN lbac_label,
                    label5 IN lbac_label,
                    label6 IN lbac_label)
RETURN lbac_label_list;


END to_label_list;
/

