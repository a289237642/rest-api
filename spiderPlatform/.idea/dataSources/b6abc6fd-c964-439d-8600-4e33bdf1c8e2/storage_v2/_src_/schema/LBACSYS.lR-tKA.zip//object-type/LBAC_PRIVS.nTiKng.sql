create TYPE         lbac_privs                                       
AS OPAQUE FIXED(9)
USING LIBRARY LBACSYS.lbac$privs_libt
(
-- The LBAC_PRIVS type contains the bit string representation of policy
-- package privileges (32 bits).  The functions provide setting, clearing,
-- and testing of specific privileges based on their numeric value.
-- Union and diff functions are also provided to operate on two sets
-- of privileges.

-- Constructor
   STATIC FUNCTION new_lbac_privs(policy_id IN PLS_INTEGER)
   RETURN lbac_privs,
   PRAGMA RESTRICT_REFERENCES(new_lbac_privs, RNDS, WNDS, RNPS, WNPS),

-- Procedures to set contents
   MEMBER PROCEDURE clear_priv(SELF IN OUT NOCOPY lbac_privs,
                               priv_number IN PLS_INTEGER),
   PRAGMA RESTRICT_REFERENCES(clear_priv, RNDS, WNDS, RNPS, WNPS),

   MEMBER PROCEDURE set_priv(SELF IN OUT NOCOPY lbac_privs,
                             priv_number IN PLS_INTEGER),
   PRAGMA RESTRICT_REFERENCES(set_priv, RNDS, WNDS, RNPS, WNPS),

   MEMBER PROCEDURE union_privs(SELF IN OUT NOCOPY lbac_privs,
                                other_privs IN lbac_privs),
   PRAGMA RESTRICT_REFERENCES(union_privs, RNDS, WNDS, RNPS, WNPS),

   MEMBER PROCEDURE diff_privs(SELF IN OUT NOCOPY lbac_privs,
                                other_privs IN lbac_privs),
   PRAGMA RESTRICT_REFERENCES(diff_privs, RNDS, WNDS, RNPS, WNPS),
-- Functions to test contents
   MEMBER FUNCTION test_priv(SELF IN lbac_privs,
                             priv_number IN PLS_INTEGER)
   RETURN BOOLEAN,
   PRAGMA RESTRICT_REFERENCES(test_priv, RNDS, WNDS, RNPS, WNPS),

   MEMBER FUNCTION none(SELF IN lbac_privs)
   RETURN BOOLEAN,
   PRAGMA RESTRICT_REFERENCES(none, RNDS, WNDS, RNPS, WNPS),

   MEMBER FUNCTION policy_id(SELF IN lbac_privs)
   RETURN PLS_INTEGER,
   PRAGMA RESTRICT_REFERENCES(policy_id, RNDS, WNDS, RNPS, WNPS)

);
/

