create PACKAGE         lbac_session AS
--
--  This package provides information about the session's security attributes
--  and supports changes to the session labels if allowed by the policy
--  package.

FUNCTION policy_enable (policy_name IN VARCHAR2)
RETURN BOOLEAN;
PRAGMA RESTRICT_REFERENCES(policy_enable, WNPS, RNDS, WNDS);

FUNCTION label_format (policy_name IN VARCHAR2)
RETURN VARCHAR2;
PRAGMA RESTRICT_REFERENCES(label_format, WNPS, RNDS, WNDS);

FUNCTION user_privileges (policy_name IN VARCHAR2)
RETURN lbac_privs;
PRAGMA RESTRICT_REFERENCES(user_privileges, WNPS, RNDS, WNDS);

FUNCTION user_labels (policy_name IN VARCHAR2)
RETURN lbac_label_list;
PRAGMA RESTRICT_REFERENCES(user_labels, WNPS, RNDS, WNDS);

FUNCTION session_initial_privileges (policy_name IN VARCHAR2)
RETURN lbac_privs;
PRAGMA RESTRICT_REFERENCES(session_initial_privileges, WNPS, RNDS, WNDS);

FUNCTION session_initial_labels (policy_name IN VARCHAR2)
RETURN lbac_label_list;
PRAGMA RESTRICT_REFERENCES(session_initial_labels, WNPS, RNDS,  WNDS);

FUNCTION effective_privileges (policy_name IN VARCHAR2)
RETURN lbac_privs;
PRAGMA RESTRICT_REFERENCES(effective_privileges, WNPS, RNDS,  WNDS);

FUNCTION effective_initial_labels (policy_name IN VARCHAR2)
RETURN lbac_label_list;
PRAGMA RESTRICT_REFERENCES(effective_initial_labels, WNPS, RNDS, WNDS);

FUNCTION effective_labels (policy_name IN VARCHAR2)
RETURN lbac_label_list;
PRAGMA RESTRICT_REFERENCES(effective_labels, WNPS, RNDS,  WNDS);

FUNCTION database_labels (policy_name IN VARCHAR2)
RETURN lbac_label_list;
PRAGMA RESTRICT_REFERENCES(database_labels, WNPS, RNDS,  WNDS);

FUNCTION policy_disabled (policy_name IN VARCHAR2)
RETURN BOOLEAN;
PRAGMA RESTRICT_REFERENCES(policy_disabled, WNPS, RNDS,  WNDS);

PROCEDURE set_label_format (policy_name  IN VARCHAR2,
                            label_format IN VARCHAR2);

PROCEDURE set_effective (policy_name IN VARCHAR2,
                         labels      IN lbac_label_list,
                         privs       IN lbac_privs);

PROCEDURE set_effective_labels (policy_name IN VARCHAR2,
                                labels IN lbac_label_list);

PROCEDURE set_effective_privs (policy_name IN VARCHAR2,
                               effective_privs IN lbac_privs);

FUNCTION bypassread (policy_name IN VARCHAR2)
RETURN BOOLEAN;
PRAGMA RESTRICT_REFERENCES(bypassread, WNPS, RNDS, WNDS);

FUNCTION bypassall (policy_name IN VARCHAR2)
RETURN BOOLEAN;
PRAGMA RESTRICT_REFERENCES(bypassread, WNPS, RNDS, WNDS);

END lbac_session;
/

