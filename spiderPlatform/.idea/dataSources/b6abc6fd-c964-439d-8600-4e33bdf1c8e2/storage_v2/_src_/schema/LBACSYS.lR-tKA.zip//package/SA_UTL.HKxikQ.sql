create PACKAGE         sa_utl AS

read_only  CONSTANT VARCHAR2(12) := 'READ_ONLY';
read_write CONSTANT VARCHAR2(12) := 'READ_WRITE';
write_only CONSTANT VARCHAR2(12) := 'WRITE_ONLY';

FUNCTION label (policy_name IN VARCHAR2)
RETURN lbac_label;

FUNCTION lbac_read_label (policy_name IN VARCHAR2)
RETURN lbac_label;

FUNCTION lbac_write_label (policy_name IN VARCHAR2)
RETURN lbac_label;

FUNCTION lbac_row_label (policy_name IN VARCHAR2)
RETURN lbac_label;

PROCEDURE set_label       (policy_name   IN VARCHAR2,
                           label         IN lbac_label);

PROCEDURE set_row_label   (policy_name   IN VARCHAR2,
                           label         IN lbac_label);

FUNCTION merge_label (label1 IN lbac_label,
                      label2 IN lbac_label,
                      merge_format IN VARCHAR2)
RETURN lbac_label;

FUNCTION greatest_lbound (label1 IN lbac_label,
                          label2 IN lbac_label)
RETURN lbac_label;

FUNCTION least_ubound (label1 IN lbac_label,
                       label2 IN lbac_label)
RETURN lbac_label;

FUNCTION dominates (label1 IN lbac_label,
                    label2 IN lbac_label)
RETURN BOOLEAN;

FUNCTION strictly_dominates (label1 IN lbac_label,
                             label2 IN lbac_label)
RETURN BOOLEAN;

FUNCTION dominated_by (label1 IN lbac_label,
                       label2 IN lbac_label)
RETURN BOOLEAN;

FUNCTION strictly_dominated_by (label1 IN lbac_label,
                                label2 IN lbac_label)
RETURN BOOLEAN;

FUNCTION numeric_label (policy_name IN VARCHAR2)
RETURN number;

FUNCTION numeric_read_label (policy_name IN VARCHAR2)
RETURN number;

FUNCTION numeric_write_label (policy_name IN VARCHAR2)
RETURN number;

FUNCTION numeric_row_label (policy_name IN VARCHAR2)
RETURN number;

FUNCTION check_read (policy_name IN VARCHAR2,
                     label       IN lbac_label)
RETURN number;

FUNCTION check_write (policy_name IN VARCHAR2,
                      label       IN lbac_label)
RETURN number;

FUNCTION check_label_change (policy_name IN VARCHAR2,
                             old_label   IN lbac_label,
                             new_label   IN lbac_label)
RETURN number;

PROCEDURE set_label       (policy_name   IN VARCHAR2,
                           label         IN number);

PROCEDURE set_row_label   (policy_name   IN VARCHAR2,
                           label         IN number);

FUNCTION merge_label (label1 IN number,
                      label2 IN number,
                      merge_format IN VARCHAR2)
RETURN number;

FUNCTION greatest_lbound (label1 IN number,
                          label2 IN number)
RETURN number;

FUNCTION least_ubound (label1 IN number,
                       label2 IN number)
RETURN number;

FUNCTION dominates (label1 IN number,
                    label2 IN number)
RETURN BOOLEAN;

FUNCTION strictly_dominates (label1 IN number,
                             label2 IN number)
RETURN BOOLEAN;

FUNCTION dominated_by (label1 IN number,
                       label2 IN number)
RETURN BOOLEAN;

FUNCTION strictly_dominated_by (label1 IN number,
                                label2 IN number)
RETURN BOOLEAN;

FUNCTION check_read (policy_name IN VARCHAR2,
                     label       IN NUMBER)
RETURN number;

FUNCTION check_write (policy_name IN VARCHAR2,
                      label       IN NUMBER)
RETURN number;

FUNCTION check_label_change (policy_name IN VARCHAR2,
                             old_label   IN number,
                             new_label   IN number)
RETURN number;

FUNCTION data_label(label IN LBAC_LABEL)
RETURN BOOLEAN;

FUNCTION data_label(label IN NUMBER)
RETURN BOOLEAN;

END sa_utl;
/

