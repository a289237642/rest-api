create view APEX_APPLICATION_PAGE_MAP as
select w.short_name                 workspace,
       p.flow_id                    application_id,
       (select name
        from wwv_flows
        where id = p.flow_id)       application_name,
       p.id                         page_id,
       p.name                       page_name,
       p.step_title                 page_title,
       --
       breadcrumb                   breadcrumb,
       ltrim((select max(short_name)
       from wwv_flow_menu_options b2
       where c.ggggg_parent_id = b2.id) ||
       ggggg_parent||' > '||
       gggg_parent||' > '||
       ggg_parent||' > '||
       great_grand_parent||' > '||
       grand_parent||' > '||
       parent_breadcrumb||' > '||
       breadcrumb,' >')             full_breadcrumb,
       help_text
from wwv_flow_steps p,
     wwv_flow_companies w,
(
select flow_id, page_id, breadcrumb_id, breadcrumb, parent_breadcrumb, grand_parent,
       great_grand_parent, ggg_parent,gggg_parent,
       (select max(short_name) from wwv_flow_menu_options b2
       where b.gggg_parent_id = b2.id and b.flow_id = b2.flow_id) ggggg_parent,
       (select max(parent_id) from wwv_flow_menu_options b2
       where b.gggg_parent_id = b2.id and b.flow_id = b2.flow_id) ggggg_parent_id
from
(
select flow_id, page_id, breadcrumb_id, breadcrumb, parent_breadcrumb, grand_parent,
       great_grand_parent, ggg_parent,
       (select max(short_name) from wwv_flow_menu_options b2
       where a.ggg_parent_id = b2.id and a.flow_id = b2.flow_id) gggg_parent,
       (select max(parent_id) from wwv_flow_menu_options b2
       where a.ggg_parent_id = b2.id and a.flow_id = b2.flow_id) gggg_parent_id
from
(
select flow_id, page_id, breadcrumb_id, breadcrumb, parent_breadcrumb, grand_parent,
       great_grand_parent,
       (select max(short_name) from wwv_flow_menu_options b2
       where z.great_grand_parent_id = b2.id and z.flow_id = b2.flow_id) ggg_parent,
       (select max(parent_id) from wwv_flow_menu_options b2
       where z.great_grand_parent_id = b2.id and z.flow_id = b2.flow_id) ggg_parent_id
from
(
select flow_id, page_id, breadcrumb_id, breadcrumb, parent_breadcrumb, grand_parent,
       (select max(short_name) from wwv_flow_menu_options b2
       where y.grand_parent_id = b2.id and y.flow_id = b2.flow_id) great_grand_parent,
       (select max(parent_id) from wwv_flow_menu_options b2
       where y.grand_parent_id = b2.id and y.flow_id = b2.flow_id) great_grand_parent_id
from
(
select flow_id, page_id, breadcrumb_id, breadcrumb, parent_breadcrumb,
       (select max(short_name) from wwv_flow_menu_options b2
       where x.parent_id = b2.id) grand_parent,
       (select max(parent_id) from wwv_flow_menu_options b2
       where x.parent_id = b2.id and x.flow_id = b2.flow_id) grand_parent_id
from
(
select flow_id, b.id breadcrumb_id, page_id, short_name breadcrumb,
       (select max(short_name) from wwv_flow_menu_options b2
       where b.parent_id = b2.id and b.flow_id = b2.flow_id) parent_breadcrumb,
       (select max(parent_id) from wwv_flow_menu_options b2
       where b.parent_id = b2.id and b.flow_id = b2.flow_id) parent_id
from wwv_flow_menu_options b
) x
) y
) z
) a
) b
) c
where p.id = c.page_id(+)
and  p.flow_id = c.flow_id
and  w.provisioning_company_id = p.flow_id
and (user = (select owner from wwv_flows where id = p.flow_id) or
     p.security_group_id = (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual))
/

comment on table APEX_APPLICATION_PAGE_MAP is 'Identifies the full breadcrumb path for each page with a breadcrumb entry'
/

comment on column APEX_APPLICATION_PAGE_MAP.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_MAP.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_MAP.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_MAP.PAGE_ID is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_MAP.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_MAP.PAGE_TITLE is 'Identifies the Page Title'
/

comment on column APEX_APPLICATION_PAGE_MAP.BREADCRUMB is 'Identifies the corresponding Page Breadcrumb Entry Text'
/

comment on column APEX_APPLICATION_PAGE_MAP.FULL_BREADCRUMB is 'Identifies the full breadcrumb hierarchy'
/

comment on column APEX_APPLICATION_PAGE_MAP.HELP_TEXT is 'Identifies the help text associated with the page'
/

