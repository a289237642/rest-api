create view APEX_MIGRATION_PROJECTS as
select
        a.project_id                                    project_id,
     --
        d.migration_name                                project_name,
     --
	d.description                                   description,
     --
        a.dbpathname                                    accdb_pathname,
     --
        a.jetversion                                    jetversion,
     --
        d.migration_type                                migration_type,
     --
        a.accessversion                                 accessversion,
     --
        d.created_by                                    project_owner,
     --
        s.schema                                        schema,
     --
        w.short_name                                    workspace,
     --
        w.provisioning_company_id                       workspace_id,
     --
        d.last_updated_on                               last_modified_on,
     --
        d.last_updated_by                               last_modified_by
     --
from
        wwv_mig_access a,
     --
        wwv_flow_company_schemas s,
     --
        wwv_mig_projects d,
     --
        wwv_flow_companies w,
     --
        (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) g
     --
where
	(s.schema = user or user in ('SYS','SYSTEM','APEX_030200') or g.sgid = w.PROVISIONING_COMPANY_ID)
and     w.PROVISIONING_COMPANY_ID != 0
and     a.database_schema = s.schema
and     a.project_id = d.id
and     a.security_group_id = d.security_group_id
and     w.provisioning_company_id = a.security_group_id
and     w.provisioning_company_id = s.security_group_id
order by w.PROVISIONING_COMPANY_ID, a.project_id
/

comment on table APEX_MIGRATION_PROJECTS is 'Available Application Express (Apex) Application Migrations Migration Projects'
/

comment on column APEX_MIGRATION_PROJECTS.PROJECT_ID is 'Primary key that identifies the migration project'
/

comment on column APEX_MIGRATION_PROJECTS.PROJECT_NAME is 'Identifies name of the migration project'
/

comment on column APEX_MIGRATION_PROJECTS.DESCRIPTION is 'A brief description of the migration project'
/

comment on column APEX_MIGRATION_PROJECTS.ACCDB_PATHNAME is 'Identifies full path name and location of the Microsoft Access database the migration project is based on'
/

comment on column APEX_MIGRATION_PROJECTS.JETVERSION is 'Version of Microsoft Jet for MS Access associated with captured Microsoft Access database'
/

comment on column APEX_MIGRATION_PROJECTS.MIGRATION_TYPE is 'Identifies the type of Migration Project'
/

comment on column APEX_MIGRATION_PROJECTS.ACCESSVERSION is 'Version of Microsoft Access database captured, which the migration project is based on'
/

comment on column APEX_MIGRATION_PROJECTS.PROJECT_OWNER is 'Identifies the Apex User Name who created and owns the Migration Project'
/

comment on column APEX_MIGRATION_PROJECTS.SCHEMA is 'Identified the name of database schema associated with the Migration Project'
/

comment on column APEX_MIGRATION_PROJECTS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_MIGRATION_PROJECTS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

comment on column APEX_MIGRATION_PROJECTS.LAST_MODIFIED_ON is 'Date of most recent changes to the Migration Project'
/

comment on column APEX_MIGRATION_PROJECTS.LAST_MODIFIED_BY is 'Identifies the APEX User Name who last modified the Migration Project'
/

