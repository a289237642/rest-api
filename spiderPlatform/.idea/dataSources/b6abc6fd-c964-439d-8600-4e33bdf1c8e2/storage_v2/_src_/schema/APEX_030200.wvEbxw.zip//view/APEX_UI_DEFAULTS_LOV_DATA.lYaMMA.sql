create view APEX_UI_DEFAULTS_LOV_DATA as
select t.schema,
       t.table_name,
       c.column_name,
       l.lov_disp_sequence,
       l.lov_disp_value,
       l.lov_return_value,
       l.last_updated_by,
       l.last_updated_on
  from wwv_flow_hnt_lov_data l,
       wwv_flow_hnt_column_info c,
       wwv_flow_hnt_table_info t
 where t.schema    = user
   and l.column_id = c.column_id
   and c.table_id  = t.table_id
/

comment on table APEX_UI_DEFAULTS_LOV_DATA is 'If you create a form, report, or tabular form that includes this column and if the appropriate Display As Type is set to use a list of values (Radio Group or Select List) then a Named List of Values will be created within the application and will be referenced by the resulting item or report column.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.SCHEMA is 'Schema owning table.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.TABLE_NAME is 'The table associated with the user interface defaults.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.COLUMN_NAME is 'The column associated with the user interface defaults.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.LOV_DISP_SEQUENCE is 'The display sequence of the static list of values record.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.LOV_DISP_VALUE is 'The display value of the static list of values record.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.LOV_RETURN_VALUE is 'The return value of the static list of values record.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_UI_DEFAULTS_LOV_DATA.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

