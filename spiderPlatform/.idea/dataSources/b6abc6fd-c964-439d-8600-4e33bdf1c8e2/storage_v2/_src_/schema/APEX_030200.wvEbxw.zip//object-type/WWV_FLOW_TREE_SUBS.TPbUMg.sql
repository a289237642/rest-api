create type wwv_flow_tree_subs as table of wwv_flow_tree_entry not null;
/

