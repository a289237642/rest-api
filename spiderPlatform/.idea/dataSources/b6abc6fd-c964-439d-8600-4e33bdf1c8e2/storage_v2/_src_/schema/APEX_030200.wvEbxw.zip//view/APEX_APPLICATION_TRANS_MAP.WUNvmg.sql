create view APEX_APPLICATION_TRANS_MAP as
select
    w.short_name                     workspace,
    m.ID                             map_id,
    m.primary_language_flow_id       primary_application_id,
    f.name                           primary_application_name,
    m.translation_flow_id            translated_application_id,
    m.translation_flow_language_code translated_app_language,
    m.translation_image_directory    translated_appl_img_dir,
    m.translation_comments           translation_comments,
    m.MAP_COMMENTS                   translation_map_comments,
    m.LAST_UPDATED_BY,
    m.LAST_UPDATED_ON
from
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     WWV_FLOW_LANGUAGE_MAP m,
     wwv_flows f,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0  and
      w.PROVISIONING_COMPANY_ID = m.security_group_id and
      f.owner = s.schema and
      f.id = m.primary_language_flow_id
/

comment on table APEX_APPLICATION_TRANS_MAP is 'Application Groups defined per workspace.  Applications can be associated with an application group.'
/

comment on column APEX_APPLICATION_TRANS_MAP.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TRANS_MAP.MAP_ID is 'Unique ID that identifies this translation mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.PRIMARY_APPLICATION_ID is 'Unique ID of the application that is the target of the translation'
/

comment on column APEX_APPLICATION_TRANS_MAP.PRIMARY_APPLICATION_NAME is 'Name of the application that is the target of the translation'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATED_APPLICATION_ID is 'Unique ID of the translated application'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATED_APP_LANGUAGE is 'Language code, for example "fr" or "pt-br"'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATED_APPL_IMG_DIR is 'Optional directory of translated images'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATION_COMMENTS is 'Comments associated with this translation'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATION_MAP_COMMENTS is 'Comments associated with this mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.LAST_UPDATED_BY is 'Last user to update this translation mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.LAST_UPDATED_ON is 'Date of last update to this translation mapping'
/

