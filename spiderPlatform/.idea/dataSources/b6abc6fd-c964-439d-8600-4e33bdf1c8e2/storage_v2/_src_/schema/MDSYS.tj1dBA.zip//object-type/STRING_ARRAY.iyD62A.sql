create TYPE string_array AS VARRAY(1048576) OF VARCHAR2(256);
/

