create type H81_index_obj_array as VARRAY (1000000) of H81_index_object;
/

