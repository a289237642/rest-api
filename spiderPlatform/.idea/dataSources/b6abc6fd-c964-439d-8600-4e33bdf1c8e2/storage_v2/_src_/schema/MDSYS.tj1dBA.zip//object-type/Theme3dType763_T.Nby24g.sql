create TYPE         "Theme3dType763_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"LOD" "LOD764_T","DefaultStyle" "Style3dType753_T","Tiling" "Tiling765_T","hidden_info" "hidden_info766_T","ExternalRepresentations" "ExternalRepresentations769_T")NOT FINAL INSTANTIABLE
/

