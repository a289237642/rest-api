create type       SDONUMLIST is table of number
/

