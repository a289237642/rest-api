create TYPE         "GridType727_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridProperties" "GridPropertiesType726_T","GridData" "GridDataType715_T","HierarchyParticipation" "HierarchyParticipation728_T")NOT FINAL INSTANTIABLE
/

