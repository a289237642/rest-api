create TYPE ST_SURFACE_ARRAY
                                      
AS VARRAY(1048576) OF ST_GEOMETRY
/

