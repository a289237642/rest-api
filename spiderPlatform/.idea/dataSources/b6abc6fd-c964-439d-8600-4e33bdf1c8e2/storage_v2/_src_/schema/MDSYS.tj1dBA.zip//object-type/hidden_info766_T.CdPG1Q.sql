create TYPE         "hidden_info766_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","field" "field768_COLL")FINAL INSTANTIABLE
/

