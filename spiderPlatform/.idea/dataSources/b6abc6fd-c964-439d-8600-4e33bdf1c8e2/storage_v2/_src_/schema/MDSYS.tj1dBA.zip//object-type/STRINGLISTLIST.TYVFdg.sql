create type       StringListList as varray(1000000) OF StringList
/

