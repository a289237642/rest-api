create type SDOAggrType as Object (
Geometry mdsys.sdo_geometry,
Tolerance  NUMBER)
/

