create TYPE         "GridNode720_COLL" AS VARRAY(2147483647) OF "GridNodeType717_T"
/

