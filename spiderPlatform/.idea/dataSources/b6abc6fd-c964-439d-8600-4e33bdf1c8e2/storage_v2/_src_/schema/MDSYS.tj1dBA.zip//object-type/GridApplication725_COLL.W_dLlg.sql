create TYPE         "GridApplication725_COLL" AS VARRAY(2147483647) OF "GridApplicationType724_T"
/

