create type       sdo_geom_path_info as table of mdsys.sdo_geom_path_elem
/

