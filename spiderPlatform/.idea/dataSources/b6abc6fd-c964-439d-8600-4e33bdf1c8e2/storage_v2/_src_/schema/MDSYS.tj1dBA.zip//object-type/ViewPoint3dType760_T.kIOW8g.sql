create TYPE         "ViewPoint3dType760_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"fadeIn" NUMBER(38),"pause" NUMBER(38),"fadeOut" NUMBER(38),"Eye" "Vector3dType761_T","Center" "Vector3dType761_T","Up" "Vector3dType761_T","Frustum3d" "Frustum3dType758_T")NOT FINAL INSTANTIABLE
/

