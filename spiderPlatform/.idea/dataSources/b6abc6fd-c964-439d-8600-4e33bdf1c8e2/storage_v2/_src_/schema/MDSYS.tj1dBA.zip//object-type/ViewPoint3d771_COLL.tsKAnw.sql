create TYPE         "ViewPoint3d771_COLL" AS VARRAY(2147483647) OF "ViewPoint3dType760_T"
/

