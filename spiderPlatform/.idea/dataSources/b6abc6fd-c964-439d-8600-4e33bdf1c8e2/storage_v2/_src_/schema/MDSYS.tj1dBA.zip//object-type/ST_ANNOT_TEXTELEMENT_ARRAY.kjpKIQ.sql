create TYPE ST_ANNOT_TEXTELEMENT_ARRAY
                                                                                  
      AS VARRAY (100000000) OF ST_ANNOTATIONTEXTELEMENT
/

