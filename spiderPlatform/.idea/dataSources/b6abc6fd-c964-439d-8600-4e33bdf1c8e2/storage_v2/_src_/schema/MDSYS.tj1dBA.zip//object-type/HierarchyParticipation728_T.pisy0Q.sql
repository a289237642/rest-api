create TYPE         "HierarchyParticipation728_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Parent" "Parent729_COLL")FINAL INSTANTIABLE
/

