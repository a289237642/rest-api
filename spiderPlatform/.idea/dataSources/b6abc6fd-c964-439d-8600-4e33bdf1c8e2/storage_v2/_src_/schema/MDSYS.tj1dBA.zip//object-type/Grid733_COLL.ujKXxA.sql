create TYPE         "Grid733_COLL" AS VARRAY(2147483647) OF "Grid730_T"
/

