create TYPE         "UnitOfMeasureType714_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","UnitOfMeasureType" "XDB"."XDB$ENUM_T","UnitOfMeasureId" NUMBER(20),"UnitOfMeasureFactor" NUMBER)NOT FINAL INSTANTIABLE
/

