create TYPE SDO_TIN_BLK_TYPE
                                                                              
    AS TABLE of MDSYS.SDO_TIN_BLK
/

