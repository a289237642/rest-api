create TYPE         "GridRow721_COLL" AS VARRAY(2147483647) OF "GridLineType716_T"
/

