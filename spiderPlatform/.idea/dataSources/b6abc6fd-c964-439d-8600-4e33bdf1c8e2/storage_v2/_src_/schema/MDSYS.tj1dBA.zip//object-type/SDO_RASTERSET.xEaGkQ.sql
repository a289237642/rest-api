create TYPE SDO_RASTERSET
                                                                      
AS TABLE of SDO_RASTER
/

