create TYPE         "Parent729_COLL" AS VARRAY(2147483647) OF "ParentType722_T"
/

