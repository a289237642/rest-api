create TYPE         "GridNodeType717_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Offset" "CoordinatesType718_T","OffsetPrecision" "CoordinatesType718_T")NOT FINAL INSTANTIABLE
/

