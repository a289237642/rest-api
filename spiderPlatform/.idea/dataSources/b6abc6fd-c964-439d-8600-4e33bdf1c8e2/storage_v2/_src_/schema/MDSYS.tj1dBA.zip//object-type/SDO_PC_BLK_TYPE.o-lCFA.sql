create TYPE SDO_PC_BLK_TYPE
                                                                              
    AS TABLE of MDSYS.SDO_PC_BLK
/

