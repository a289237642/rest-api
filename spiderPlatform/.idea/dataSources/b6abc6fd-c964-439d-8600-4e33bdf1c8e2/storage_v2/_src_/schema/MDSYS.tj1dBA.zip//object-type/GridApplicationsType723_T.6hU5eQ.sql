create TYPE         "GridApplicationsType723_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridApplication" "GridApplication725_COLL")NOT FINAL INSTANTIABLE
/

