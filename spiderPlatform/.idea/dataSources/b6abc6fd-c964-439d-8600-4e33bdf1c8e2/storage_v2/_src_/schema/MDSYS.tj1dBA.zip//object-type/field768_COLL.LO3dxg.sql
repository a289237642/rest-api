create TYPE         "field768_COLL" AS VARRAY(2147483647) OF "field767_T"
/

