create TYPE         "ViewFrame3dType759_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","SceneName" VARCHAR2(4000 CHAR),"ViewPoint3d" "ViewPoint3dType760_T","DefaultStyle" "Style3dType753_T")NOT FINAL INSTANTIABLE
/

