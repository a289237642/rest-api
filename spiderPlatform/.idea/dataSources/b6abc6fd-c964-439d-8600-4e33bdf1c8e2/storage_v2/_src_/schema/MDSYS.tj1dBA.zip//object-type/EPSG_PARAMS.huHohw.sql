create TYPE       epsg_params
AS VARRAY(1048576) OF MDSYS.epsg_param;
/

