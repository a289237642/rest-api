create TYPE         "Scene3dType747_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"Theme" "Theme749_COLL","ExternalTheme" "ExternalTheme752_COLL","DefaultStyle" "Style3dType753_T")NOT FINAL INSTANTIABLE
/

