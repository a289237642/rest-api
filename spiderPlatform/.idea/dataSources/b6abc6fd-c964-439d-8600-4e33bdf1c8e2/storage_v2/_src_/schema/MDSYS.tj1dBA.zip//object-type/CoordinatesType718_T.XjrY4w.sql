create TYPE         "CoordinatesType718_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Coordinate" "Coordinate719_COLL")NOT FINAL INSTANTIABLE
/

