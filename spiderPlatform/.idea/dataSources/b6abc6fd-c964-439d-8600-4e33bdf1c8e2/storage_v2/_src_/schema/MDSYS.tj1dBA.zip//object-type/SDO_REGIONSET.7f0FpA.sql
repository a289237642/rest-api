create TYPE SDO_REGIONSET
                                                                      
AS TABLE OF SDO_REGION
/

