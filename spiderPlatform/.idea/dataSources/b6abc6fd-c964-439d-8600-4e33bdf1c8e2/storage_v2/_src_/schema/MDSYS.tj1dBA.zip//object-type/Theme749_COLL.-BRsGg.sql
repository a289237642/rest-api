create TYPE         "Theme749_COLL" AS VARRAY(2147483647) OF "Theme748_T"
/

