create TYPE         "TextureType755_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TextureBLOB" "SharedValueType754_T","TextureCoordinates" "SharedValueType754_T")NOT FINAL INSTANTIABLE
/

