create type H81_nt_ind_type as table of H81_index_object;
/

