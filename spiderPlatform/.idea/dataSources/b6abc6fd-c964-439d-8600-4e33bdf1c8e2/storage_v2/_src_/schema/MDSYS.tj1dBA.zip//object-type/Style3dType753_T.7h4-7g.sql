create TYPE         "Style3dType753_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Color" "SharedValueType754_T","Texture" "TextureType755_T","ModelStyle" "FeatureReferenceType744_T","Normals" "Normals756_T")NOT FINAL INSTANTIABLE
/

